self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "dd373e0195e000c24eb0a5509f36f170",
    "url": "/onetapdev/index.html"
  },
  {
    "revision": "9e3ff2ba9066b80d6e05",
    "url": "/onetapdev/static/css/main.d38bf5f9.chunk.css"
  },
  {
    "revision": "184d897c7cbb93714290",
    "url": "/onetapdev/static/js/2.8843adbb.chunk.js"
  },
  {
    "revision": "3453b8997016469371284a28c0e873e2",
    "url": "/onetapdev/static/js/2.8843adbb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9e3ff2ba9066b80d6e05",
    "url": "/onetapdev/static/js/main.ccf2e464.chunk.js"
  },
  {
    "revision": "b0d56105e39e02f73191",
    "url": "/onetapdev/static/js/runtime-main.1324794c.js"
  },
  {
    "revision": "a6ffc5d72a96b65159e710ea6d258ba4",
    "url": "/onetapdev/static/media/Menlo-Bold.a6ffc5d7.ttf"
  },
  {
    "revision": "9f023a877b3c05ea66c9bae8cb80e4ae",
    "url": "/onetapdev/static/media/Menlo-BoldItalic.9f023a87.ttf"
  },
  {
    "revision": "7bc79a7a467fcf7630d37a688238a0d0",
    "url": "/onetapdev/static/media/Menlo-Italic.7bc79a7a.ttf"
  },
  {
    "revision": "9f94dc20bb2a09c15241d3a880b7ad01",
    "url": "/onetapdev/static/media/Menlo-Regular.9f94dc20.ttf"
  }
]);